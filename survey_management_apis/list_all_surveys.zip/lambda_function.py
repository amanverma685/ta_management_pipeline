import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True


def lambda_handler(event, context):
    print(event)
    user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
    print(user_id) 
    cursor = conn.cursor()
    try:
        sqlQuery=f"""SELECT json_build_object('surveyList', json_agg(row_to_json(t))) 
                FROM ( SELECT * FROM surveys INNER JOIN requester_surveys ON 
                surveys.survey_id = requester_surveys.survey_id and requester_surveys.requester_id='{user_id}' ) t ; """
                
        # sql= f""" SELECT json_agg(surveys) FROM surveys group by created_date order by created_date desc ; """
        
        print(sqlQuery)
        cursor.execute(sqlQuery)
        data= cursor.fetchall()
        
        if "surveyList" in data[0][0]:
            responseData=data[0][0]['surveyList']
        
        else :
            responseData=[]
        cursor.close()

        if len(responseData)  :
            return returnResponse({
                    "success": True,
                    "message": "List of survey",
                    "statusCode": 200,
                    "responseData":responseData
                    })
        else :
            return returnResponse({
                    "success": True,
                    "message": "No survey found",
                    "statusCode": 200,
                    "responseData":[]
                    }) 
        
    except Exception as e:
            return returnResponse({
                    "success": False, 
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":[]
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    