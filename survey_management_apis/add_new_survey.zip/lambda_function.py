import json
import psycopg2
import uuid
from datetime import datetime
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    # body = json.loads(event.get('body'))
    user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
    body = event.get('body')
    try:
        cursor = conn.cursor()
        survey_id="SUR"+str(uuid.uuid4().node)
        survey_id = survey_id[:12]
        students_criteria = json.dumps(body.get('studentsCriteria',{}))
        devices = json.dumps(body.get('devices',[]))
        department_name = event['requestContext']['authorizer']['claims']['custom:department_name']
        
        now = datetime.now()

        query=f"""Insert into surveys (
                survey_id,
                survey_title,
                description,
                survey_url,
                num_of_respondents,
                max_credits,
                created_date,
                start_date,
                expiry_date,
                is_active,
                survey_time,
                survey_time_unit,
                students_criteria,
                devices,
                survey_status)
            VALUES (
                '{survey_id}',
                '{body.get('title')}',
                '{body.get('description')}',
                '{body.get('surveyUrl')}',
                '{body.get('studentsRequired')}',
                '{body.get('creditsReward')}',
                '{now}',
                '{body.get('startDate')}',
                '{body.get('endDate')}',
                 false,
                '{body.get('surveyTimeValue')}',
                '{body.get('surveyTimeUnit')}',
                '{students_criteria}'::jsonb,
                '{devices}'::jsonb,
                'Draft'
                ); """
        cursor.execute(query)
        
        query=f"""Insert into requester_surveys (
                requester_id,
                survey_id,
                department_name,
                survey_status,
                inserted_date,
                updated_date,
                credits,
                bonuses)
            VALUES (
                '{user_id}',
                '{survey_id}',
                '{department_name}',
                'Active',
                '{now}',
                '{now}',
                '{body.get('creditsReward')}',
                '{body.get('bonus',0)}'
                ); """
        cursor.execute(query)
        
        cursor.close()

    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":[]
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"Survey has been created successfull",
                    "statusCode": 200,
                    "responseData":[]
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    