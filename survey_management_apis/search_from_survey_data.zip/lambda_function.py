import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True


def lambda_handler(event, context):
    print(event)
    
    body = json.loads(event.get('body'))
    searchKey = body.get('searchKey')
    # searchKey="survey"
    cursor = conn.cursor()
    try:
        sql= f""" SELECT json_agg(t) FROM (
            SELECT *
            FROM surveys
            WHERE to_tsvector('english', survey_title || ' ' || description || ' ' || survey_id) @@ to_tsquery('english', '{searchKey}')
        ) t; """
        cursor.execute(sql)
        data= cursor.fetchall()
        
        if data[0][0]!=None:
            
            responseData=[]
            for one_data in data :
                responseData.append(one_data[0][0])
            cursor.close()
    
            if len(responseData)  :
                return returnResponse({
                        "success": True,
                        "message": "List of survey",
                        "statusCode": 200,
                        "responseData":responseData
                        })
        else :
            return returnResponse({
                    "success": True,
                    "message": "No survey found",
                    "statusCode": 200,
                    "responseData":[]
                    }) 
        
    except Exception as e:
            return returnResponse({
                    "success": False, 
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":[]
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    