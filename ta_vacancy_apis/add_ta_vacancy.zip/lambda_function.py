import json
import psycopg2
from datetime import datetime
import os
import uuid
import boto3


DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']
client = boto3.client('cognito-idp') 

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    try:
        cursor = conn.cursor()
        symactic_id_prefix= "TAVAC"
        symactic_id = symactic_id_prefix + str(uuid.uuid4())

        #make symactic id of length 12
        symactic_id = symactic_id[0:12]
        

        body = json.loads(event.get('body'))
        subject = json.dumps(body.get('subject'))
        
        
        user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
        

        if 'ta_vac_id' in body.keys():
            query = f""" UPDATE ta_vacancy_form
                        SET number_of_vacancy = '{body.get('number_of_vacancy')}',
                        eligibility = '{body.get('eligibility')}',
                        minimum_grade = '{body.get('minimum_grade')}',
                        current_registered = '{body.get('current_registered')}',
                        remarks = '{body.get('remarks')}',
                        semester = '{body.get('semester')}',
                        deadline = '{body.get('deadline')}',
                        professor_id = '{user_id}'
                        WHERE ta_vac_id = '{body.get('ta_vac_id')}'"""
        
        else :
            query = f"""INSERT INTO ta_vacancy_form (ta_vac_id,professor_id, subject, number_of_vacancy, eligibility,status, minimum_grade, remarks,
            semester,deadline,current_registered) VALUES 
            ('{symactic_id}','{user_id}', '{subject}','{body.get('number_of_vacancy')}','{body.get('eligibility')}','active','{body.get('minimum_grade')}','{body.get('remarks')}','{body.get('semester')}','{body.get('deadline')}',0)"""

        cursor.execute(query)

        cursor.close()

        
        
    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":{}
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"TA Vacancy has been registered successfully",
                    "statusCode": 200,
                    "responseData":{}
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    