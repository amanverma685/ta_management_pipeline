import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True


def lambda_handler(event, context):
    print(event)
    cursor = conn.cursor()
    try:
        sql= f"""SELECT json_agg(json_build_object('month', month, 'active', active_count, 'completed', published_count, 'draft', draft_count))
        FROM (
          SELECT 
            to_char(date_trunc('month', created_date), 'YYYY-MM') AS month,
            COUNT(*) FILTER (WHERE survey_status = 'Active') AS active_count,
            COUNT(*) FILTER (WHERE survey_status = 'Draft') AS draft_count,
            COUNT(*) FILTER (WHERE survey_status = 'Completed') AS published_count
          FROM surveys
          GROUP BY month
          ORDER BY month
        ) AS result;"""
        cursor.execute(sql)
        data= cursor.fetchall()
        
        if data[0][0]!=None:
            
            responseData=[]
            for one_data in data :
                responseData.append(one_data[0][0])
            cursor.close()
    
            if len(responseData)  :
                return returnResponse({
                        "success": True,
                        "message": "List of survey",
                        "statusCode": 200,
                        "responseData":responseData
                        })
        else :
            return returnResponse({
                    "success": True,
                    "message": "No survey found",
                    "statusCode": 200,
                    "responseData":[]
                    }) 
        
    except Exception as e:
            return returnResponse({
                    "success": False, 
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":[]
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    