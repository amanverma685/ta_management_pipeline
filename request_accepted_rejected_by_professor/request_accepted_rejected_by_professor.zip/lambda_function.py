import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

import datetime

def lambda_handler(event, context):
    print(event)
    current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    body = json.loads(event.get('body'))
    
    cursor = conn.cursor()
    
    sql = f"""select current_registered,number_of_vacancy from ta_vacancy_form where ta_vac_id = '{body.get('ta_vac_id')}'"""
    cursor.execute(sql)
    data = cursor.fetchall()
    total_vacancy = data[0][1]
    current_registered = data[0][0]
    
    if current_registered>=total_vacancy :
        return returnResponse({
                    "success": False, 
                    "message": "Registrations are full",
                    "statusCode": 500,
                    "responseData":[]
                    })
    elif body.get('request_status') == 'accepted':
        sql = f""" Update ta_vacancy_form 
        set current_registered = '{current_registered+1}'
        where ta_vac_id =  '{body.get('ta_vac_id')}'"""
        cursor.execute(sql)
        
    else :
        sql = f""" Update ta_vacancy_form 
        set current_registered = '{current_registered - 1}'
        where ta_vac_id =  '{body.get('ta_vac_id')}'"""
        cursor.execute(sql)
         
    try:
        sql= f"""
            UPDATE  student_response 
            set request_status = '{body.get("request_status")}',
            accepted_timestamp = '{current_timestamp}'
            where student_request_id = '{body.get('student_request_id')}';
            """
        cursor.execute(sql)
        
        cursor.close()
    
        return returnResponse({
                        "success": True,
                        "message": "Accepted Successfully",
                        "statusCode": 200,
                        "responseData":[]
                        })
        
    except Exception as e:
            return returnResponse({
                    "success": False, 
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":str(e)
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    