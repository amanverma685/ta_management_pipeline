import json
import psycopg2
from datetime import datetime
import os
import boto3

DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']
client = boto3.client('cognito-idp') 

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    try:
        cursor = conn.cursor()
        
        body = json.loads(event.get('body'))
        subject = json.dumps(body.get('subject',[]))
        subjects_in_current_sem = json.dumps(body.get('subjects_in_current_sem',[]))
        
        user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
        
        query= f""" UPDATE users  
        SET fname = '{body.get('fname')}',
        mname ='{body.get('mname')}',
        lname = '{body.get('lname')}',
        mobile_number = '{body.get('contact')}',
        user_type = '{body.get('userType')}',
        is_user_registered = True,
        roll_number = '{body.get('roll_number',"")}',
        dob = '{body.get('dob')}',
        current_sem = '{body.get('current_sem',"")}',

        current_course='{body.get('current_course',"")}',
        subject = '{subject}'::jsonb,
        subjects_in_current_sem = '{subjects_in_current_sem}'::jsonb,
        qualification = '{body.get('qualification',"")}'
        where user_id = '{user_id}' ;"""
        cursor.execute(query)
        
        cursor.close()
        
        try:
            response = client.admin_add_user_to_group(
            UserPoolId="ap-south-1_cKnp6b0v0",
            Username=body.get('email'),
            GroupName=body.get('userType')
            )
            print(response)
        except Exception as e:
            print(e)
        
        
        
    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":{}
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"User Data updated successfully",
                    "statusCode": 200,
                    "responseData":{}
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    