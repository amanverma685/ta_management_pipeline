import json
import psycopg2
from datetime import datetime
import os
import boto3

DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']
client = boto3.client('cognito-idp') 

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    try:
        cursor = conn.cursor()

        user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
        # user_id ="USER28842555"
        
        query= f""" SELECT json_agg(subject_name) from student_response  
        where user_id = '{user_id}' and request_status = 'accepted' ;"""
        
        cursor.execute(query)
        respData = cursor.fetchall()
        
        if(respData[0][0]==None):
            responseData=[]
        else :
            responseData=respData[0][0]
        
        
        cursor.close()

    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":{}
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"User Data ",
                    "statusCode": 200,
                    "responseData":responseData
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    