import psycopg2

from datetime import datetime
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

class UserSignUp:
    def registerUser(event,user_id):
        
        now = datetime.now()
        cursor = conn.cursor() 
        
        user_group_name = event.get('custom:user_group')
        
        if user_group_name=="requester" :
            user_group_id = 2
        
        elif user_group_name=="admin" :
            user_group_id=1
        else :
            user_group_id = 3
        
        try:
            customer_sql= f""" INSERT into users 
            ( 
            user_id,
            salutation,
            ethnicity_id,
            user_type_id,
            first_name,
            middle_name,
            last_name,
            phone_number,
            email_id,
            department_id,
            age,
            gender,
            current_location,
            country_of_birth,
            research_area,
            university_name,
            department_name,
            is_active
            ) 
            VALUES ( 
            '{user_id}',
            '{event.get('custom:salutation',"")}',
            '{event.get('custom:ethnicity_id',1)}',
            '{user_group_id}',
            '{event.get('custom:first_name',"")}',
            '{event.get('custom:middle_name',"")}',
            '{event.get("custom:last_name","")}',
            '{event.get('custom:mobile_no',"")}',
            '{event.get('email',"")}',
            '{event.get('custom:department_id',"")}',
            '{event.get('custom:age',25)}',
            '{event.get('custom:gender',"")}',
            '{event.get('custom:country',"")}',
            '{event.get('custom:country_of_birth',"")}',
            '{event.get('custom:research_area',"")}',
            '{event.get('custom:university_name',"")}',
            '{event.get('custom:department_name',"")}',
            true
            );   
              """
            if event.get('custom:userType') == 'guest':
                cursor.execute(guest_sql)
            else:
                cursor.execute(customer_sql)
            
            if cursor.rowcount == 1 :
                cursor.close()
                return {
                        "success": True,
                        "message": "User has been registered successfully.",
                        "statusCode": 200,
                        "responseData":[]
                        }      
            else :
                cursor.close()
                return {
                    "success": False,
                    "message": "User details has not been added to the database.",
                    "statusCode": 500,
                    "responseData":[]
                    }
                
        except (Exception) as error :
            print(error)
            return {
                    "success": False,
                    "message": str(error),
                    "statusCode": 500,
                    "responseData":[]
                    }