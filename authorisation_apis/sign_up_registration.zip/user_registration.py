import psycopg2

from datetime import datetime
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

class UserSignUp:
    def registerUser(event,user_id):
        
        now = datetime.now()
        cursor = conn.cursor() 
        email = event['request']['userAttributes']['email']
        
        try:
            customer_sql= f""" INSERT into users
            ( 
            user_id,
            email,
            is_user_registered
            ) 
            VALUES ( 
            '{user_id}',
            '{email}',
            false
            );   
              """
           
            cursor.execute(customer_sql)
            
            cursor.close()
            return {
                        "success": True,
                        "message": "User has been registered successfully.",
                        "statusCode": 200,
                        "responseData":[]
                    }      
                
        except (Exception) as error :
            print(error)
            return {
                    "success": False,
                    "message": str(error),
                    "statusCode": 500,
                    "responseData":[]
                    }