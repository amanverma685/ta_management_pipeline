import boto3
from boto3.dynamodb.conditions import Key, Attr
import botocore.exceptions
import os

USER_POOL_ID = os.environ['user_pool_id']
CLIENT_ID = os.environ['client_id']

client = boto3.client('cognito-idp') 

class CognitoService:
    def registerUserInCognito(email,password,phone_number, customer_id):
        try:
            resp = client.sign_up(
                ClientId=CLIENT_ID,
                Username=email,
                Password=password, 
                UserAttributes=[
                {
                    'Name': "email",
                    'Value': email
                },
                {
                    'Name': "phone_number",
                    'Value': phone_number
                },
                {
                    'Name': "custom:customer_id",
                    'Value': customer_id
                }

                ],
                ValidationData=[
                    {
                        'Name': "email",
                        'Value': email
                    },
                    {
                        'Name': "phone_number",
                        'Value': phone_number
                    },
                    {
                        'Name': "custom:customer_id",
                        'Value': customer_id
                    }
                ])
        except client.exceptions.UsernameExistsException as e:
            return {"error": True, 
                "success": False, 
                "message": "This username already exists", 
                "data": None}    
        except client.exceptions.InvalidPasswordException as e:
            return {"error": True, 
                "success": False, 
                "message": "Password should have Caps,\
                            Special chars, Numbers", 
                "data": None}
        except client.exceptions.UserLambdaValidationException as e:
            return {"error": True, 
                    "success": False, 
                    "message": "Email already exists", 
                    "data": None}
        except Exception as e:
            return {"error": True, 
                    "success": False, 
                    "message": str(e), 
                    "data": None}
        return {"error": False, 
                "success": True, 
                "message": "Please confirm your signup, check text message for validation code", 
                "data": None
                }
    def addUserToGroup(group_name,user_name):
        try:
            response = client.admin_add_user_to_group(
            UserPoolId=USER_POOL_ID,
            Username=user_name,
            GroupName=group_name
            )
            print(response)
        except Exception as e:
            print(e)
            