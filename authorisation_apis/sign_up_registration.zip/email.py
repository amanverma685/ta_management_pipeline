import boto3
from datetime import datetime
import os

client = boto3.client('cognito-idp')
SESclient = boto3.client('ses',region_name='us-east-1')
BOOKINGPORTAL = os.environ['extra_charges_portal']
link = BOOKINGPORTAL
class EmailService:
    def sendEmail(email_id,customer_details):
        print(customer_details.get('custom:first_name',None))
        link= BOOKINGPORTAL+'/auth/login'
        try:
            SESclient.send_email(
                            Source = "rentalalerts@cheapvehiclerentals.onmicrosoft.com",
                            Destination  ={
                            'ToAddresses': [
                                email_id
                            ]
                        },
                        Message = {
                            'Subject' : {
                                'Data' : 'Registration Completed'
                            },
                            'Body' : {
                                'Html': {
                                    'Data' : '<html><body><b>Hello '+ customer_details.get('custom:first_name',None) + ', '+'</b><br /><p>Thank you for joining Cheap Vehicle Rentals. </p><p> We&#8217;d like to confirm that your account was created successfully. To login click the link below.</p><a href='+link+'>Click here to login'+'</a>'+'<p>Regards,</p><p>Customer Service</p><p>Cheap Vehicle Rentals</p></body></html>'
                                }
                            }
                        }
                        )
        except Exception as e:
            print(e)