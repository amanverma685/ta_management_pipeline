import uuid
import os
import boto3
from cognito_service import CognitoService
from user_registration import UserSignUp

USERPOOLID = os.environ['user_pool_id']
CLIENTID = os.environ['client_id']

client = boto3.client('cognito-idp')
symactic_id_prefix= "USER"

def lambda_handler(event, context):
    print(event)
    if event.get('triggerSource') == "PostConfirmation_ConfirmSignUp" :
        data_from_cognito_trigger = event.get('request').get('userAttributes')
        
        user_id = symactic_id_prefix+str(uuid.uuid4().node)
        user_id = user_id[:12] 
        

        
        response = client.admin_update_user_attributes(
        UserPoolId= USERPOOLID,
        Username=event.get('request').get('userAttributes').get('email'),
        UserAttributes=[
            {
                'Name': 'custom:user_id',
                'Value': user_id
            }
            ]
        )
        
        # CognitoService.addUserToGroup(user_group_name,event.get('request').get('userAttributes').get('email'))
        UserSignUp.registerUser(event,user_id)
        return  event
    else  :
        return event

