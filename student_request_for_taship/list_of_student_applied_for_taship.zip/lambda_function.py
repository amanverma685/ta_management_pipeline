import json
import psycopg2
from datetime import datetime
import os
import uuid
import boto3


DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']
client = boto3.client('cognito-idp') 


conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    try:
        cursor = conn.cursor()
        
        user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
        

        query = f"""SELECT json_agg(results)
                FROM (
                  SELECT *
                  FROM student_response 
                  INNER JOIN users ON student_response.user_id = users.user_id
                  WHERE student_response.professor_id = '{user_id}'
                ) results; """

        cursor.execute(query)
        
        responseData= cursor.fetchall()[0][0]
        
        print(responseData)
        if responseData == None:
            responseData=[]
            
        for data in responseData :
            del data['subject']
            del data['subjects_in_current_sem']
        
        cursor.close()

        
        
    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":{}
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"List of students applied for TA",
                    "statusCode": 200,
                    "responseData":responseData
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    