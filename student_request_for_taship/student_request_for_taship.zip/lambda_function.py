import json
import psycopg2
from datetime import datetime
import os
import uuid
import boto3


DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']
client = boto3.client('cognito-idp') 

import datetime

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

def lambda_handler(event, context):
    print(event)
    try:
        current_datetime = datetime.datetime.now()
        print(current_datetime)
        cursor = conn.cursor()
        symactic_id_prefix= "TAREQ"
        symactic_id = symactic_id_prefix + str(uuid.uuid4())

        #make symactic id of length 12
        symactic_id = symactic_id[0:12]
        

        body = json.loads(event.get('body'))
        why_applied= body.get('whyApply')
        user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
        

        query = f"""INSERT INTO student_response (
        student_request_id,
        subject_name,
        why_applied,
        previous_grade,
        requested_timestamp,
        user_id,
        roll_number,
        ta_vac_id,
        request_status,
        experience,
        professor_id
        ) VALUES 
        (
        '{symactic_id}',
        '{body.get('subject')}',
        '{why_applied}',
        '{body.get('grade')}',
        '{current_datetime}',
        '{user_id}',
        '{body.get('roll_number')}',
        '{body.get('ta_vacancy_id')}',
         'pending',
         '{body.get('experience')}',
         '{body.get('professor_id')}
         )"""

        cursor.execute(query)

        cursor.close()

        
        
    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":{}
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"TA Vacancy has been registered successfully",
                    "statusCode": 200,
                    "responseData":{}
                    })
    

def returnResponse(body):
    return {
        'statusCode': body['statusCode'],
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    