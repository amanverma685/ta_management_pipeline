import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True

import datetime
 
def lambda_handler(event, context):
    
    user_id = event['requestContext']['authorizer']['claims']['custom:user_id']
    cursor = conn.cursor()

    try:
        
        query = f""" SELECT json_build_object(
         'pending', count(*) FILTER (WHERE request_status = 'pending'),
         'accepted', count(*) FILTER (WHERE request_status = 'accepted'),
         'rejected', count(*) FILTER (WHERE request_status = 'rejected')
         )
        FROM student_response
        WHERE user_id = '{user_id}'"""
        
        cursor.execute(query)
        
        responseData = cursor.fetchall()[0][0]
        
        
    except (Exception) as e:
        print(e)
        return returnResponse({
                    "success": False,
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":[]
                    })
    
    return returnResponse({
                    "success": True,
                    "message":"",
                    "statusCode": 200,
                    "responseData":responseData
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    