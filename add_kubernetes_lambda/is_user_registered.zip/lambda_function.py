import json
import psycopg2
import os
DATABASE = os.environ['database']
USER = os.environ['user']
PORT = os.environ['port']
PASSWORD = os.environ['password']
HOST = os.environ['host']

conn = psycopg2.connect(
    database=DATABASE, user=USER, password=PASSWORD, host=HOST, port=PORT
)
conn.autocommit = True


def lambda_handler(event, context):
    print(event)
    cursor = conn.cursor()
    user_id = event['pathParameters']['user_id']
    try:
        sql= f"""
            SELECT is_user_registered from USERS
            where user_id = '{user_id}';
            """
        cursor.execute(sql)
        
        data = cursor.fetchall()
        responseData=data[0][0]
        cursor.close()
    
        return returnResponse({
                        "success": True,
                        "message": responseData,
                        "statusCode": 200,
                        "responseData":responseData
                        })
        
    except Exception as e:
            return returnResponse({
                    "success": False, 
                    "message": str(e),
                    "statusCode": 500,
                    "responseData":str(e)
                    })


def returnResponse(body):
    return {
        'statusCode': body.get('statusCode'),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body),
        "isBase64Encoded": False,
    }
    
    
    

    